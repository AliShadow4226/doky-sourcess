constconst Discord = require('discord.js');
const Canvas = require('canvas')
const fs = require('fs').promises;
const client = new Discord.Client({
    intents: [
        Discord.Intents.FLAGS.GUILD_VOICE_STATES,
        Discord.Intents.FLAGS.GUILDS
    ]
});

client.on('ready', () => {
    console.log('ready');
    setInterval(changeBanner, 60000)
    let hungry = [let targetguild = client.guilds.cache.get("394910662662553600") , "d•|•b"]
    let Power = Math.floor(Math.random() * hungry.length);
    client.user.setActivity(hungry[Power], {type: "PLAYING"});
  }; setInterval(YousamPower, 10000)
});

async function changeBanner() {
    const images = await fs.readdir('images');
    const image = `images/${images[Math.floor(Math.random() * images.length)]}`;
    const guild = client.guilds.cache.get('394910662662553600');
    const number = await getVoiceMembers(guild);
    const banner = await editBanner(image, getVoiceMembers(guild));
    await guild.setBanner(banner);
}

function getVoiceMembers(guild) {
    let count = 0;
    guild.voiceStates.cache.each(() => count++)
    return count
}

async function editBanner(image, number) {
    const canvas = Canvas.createCanvas(1920, 1080);
    const context = canvas.getContext('2d');
    const background = await Canvas.loadImage(image);
    context.drawImage(background, 0, 0, canvas.width, canvas.height);
    context.font = '100px sans-serif';
    context.fillStyle = '#ffffff';
    context.fillText(`Total Mic: ${number}`, 100, 900);
    return canvas.toBuffer();
}

client.login("ODA1NDA1NzA5MTM5MzEyNjcw.GeCz1a._Qwdvc_I2RbRZuO8kHmm9whCm7V3KvevIq4SGQ")